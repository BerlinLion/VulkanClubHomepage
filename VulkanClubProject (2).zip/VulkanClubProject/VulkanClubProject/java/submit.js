
var text1 = "Good morning";
var text2 = " John";
var x = 2;
var y = 3;
var z = x+y;
alert(text1+text2);
alert("2 + 3 ist " + z);

var name = prompt("Please enter your name");
document.write("Your name is " + name);